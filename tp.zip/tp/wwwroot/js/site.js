﻿    function MostrarTemporadas(IdSer)
    {
        $.ajax(
            {
                type:"POST",
                dataType: "JSON",
                url: "/Home/VerTemporadas",
                data:{  IdSerie:IdSer},
                success:
                    function(response){
                        let texto = "";
                        console.log(response);
                        for(let item of response)
                        {
                            texto += (item.response + ". " + item.tituloTemporada + "<br>");
                        }
                        $("#info").html(texto);
                    }
            });
    }