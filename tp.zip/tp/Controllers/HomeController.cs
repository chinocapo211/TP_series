﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using tp.Models;

namespace tp.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        ViewBag.listaS = BD.ObtenerSeries();
        return View();
    }

    public List<Actores> VerActores(int IdSerie){
        ViewBag.actor = BD.ObtenerActores(IdSerie);
        return ViewBag.actor;
    }

    public List<Temporadas> VerTemporadas(int IdSerie){
        ViewBag.temporada = BD.ObtenerTemporadas(IdSerie);
        return ViewBag.temporada;
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
