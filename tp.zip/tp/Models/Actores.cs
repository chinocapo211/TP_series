public class Actores{
    public int IdActor{get;set;}
    public int IdSeries{get;set;}
    public string Nombre{get;set;}
}