using System.Data.SqlClient;
using Dapper;
public static class BD
{
    private static string _connectionString = @"Server=localhost;DataBase=BDSeries;Trusted_Connection=True;";
    public static List<Actores> ObtenerActores(int IdSerie){
        string sql = "SELECT * FROM Actores WHERE IdSerie == @IdSerie";
        List<Actores> listaA = new List<Actores>{}; 
        using(SqlConnection db = new SqlConnection(_connectionString))
        {
           listaA = db.Query<Actores>(sql, new{IdSerie = IdSerie}).ToList();
        }
        return listaA;
    }
    public static List<Temporadas> ObtenerTemporadas(int idSerie){
        
        List<Temporadas> listaT = new List<Temporadas>();
        using(SqlConnection db = new SqlConnection(_connectionString))
        {
            string sql = "SELECT * FROM Temporadas WHERE idSerie = @pIdSerie";
           listaT = db.Query<Temporadas>(sql, new{pIdSerie = idSerie}).ToList();
        }
        return listaT;
    }
    public static List<Series> ObtenerSeries(){
        string sql = "SELECT * FROM Series";
        List<Series> listaS = new List<Series>{};
        using(SqlConnection db = new SqlConnection(_connectionString))
        {
           listaS = db.Query<Series>(sql).ToList();
        }
        return listaS;
    }
    public static Series ObtenerInfo(int IdSerie){
        string sql = "SELECT * FROM Series WHERE IdSerie == @IdSerie";
        Series devolver;
        using(SqlConnection db = new SqlConnection(_connectionString))
        {
           devolver = db.Query<Series>(sql).FirstOrDefault();
        }
        return devolver;
    }
}